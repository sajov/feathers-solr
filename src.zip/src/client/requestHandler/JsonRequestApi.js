/**
 * https://cwiki.apache.org/confluence/display/solr/JSON+Request+API
 */
export function someMethod() {
    console.log('someMethod');
}

export var another = {};