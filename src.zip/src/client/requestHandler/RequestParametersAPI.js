/**
 * https://cwiki.apache.org/confluence/display/solr/Request+Parameters+API
 */
export function someMethod() {
    console.log('someMethod');
}

export var another = {};