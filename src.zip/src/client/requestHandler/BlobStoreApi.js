export function someMethod() {
    console.log('someMethod');
}

export var another = {};