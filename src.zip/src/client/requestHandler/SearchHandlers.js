export function someMethod() {
    console.log('someMethod');
}

export var another = {
    'test':1
};

export function testMe() {
    console.log('testMe');
}