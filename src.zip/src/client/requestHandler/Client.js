var request = require('request');

class Client {
  constructor(config) {
    this.config = config;
    this.request = request;
  }



}

exports.Client = Client;